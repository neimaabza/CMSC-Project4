
/**
 * @author Neima Abza
 */
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedList;

public class CourseDBStructure implements CourseDBStructureInterface{
	
	public LinkedList<CourseDBElement>[] hashTable;
	private int size;
	

    /**
     * A constructor that takes in an integer which represents the size of the hash table
     * @param num the size of the hash table.
     */
	@SuppressWarnings("unchecked")
	public CourseDBStructure(int num) {
		this.size = num;
		hashTable = new LinkedList[size];		
	}
	
	/**
	 * This constructor will take in a String and an int.  The string will be "Testing"
	 * and the int will be the size of the hash table.  This is used only for testing. 
	 * @param test 
	 * @param num
	 */
	@SuppressWarnings("unchecked")
	public CourseDBStructure(String test, int num) {
		this.size = num;
		hashTable = new LinkedList[size];
	}
	
	/**
	 * Use the hashCode of the CourseDatabaseElement to see if it is in the hashTable 
	 * If the CourseDatabaseElement does not exist in the hashTable, add it to the hashTable.
	 * @param element the CourseDBElement to be added
	 */
	@Override
	public void add(CourseDBElement element) {
		
		int hashIndex = element.hashCode() % getTableSize();
		
		if(hashIndex < 0) {
			hashIndex += size;
		}
		
		if(hashTable[hashIndex]!=null) {
			hashTable[hashIndex].add(element);
		}
		else {
			hashTable[hashIndex] = new LinkedList<CourseDBElement>();
			hashTable[hashIndex].add(element);
		}
		
	}
	
	/**
	 * Use the hashcode of the CourseDatabaseElement to see if it is in the hashTable 
	 * If the CourseDatabaseElement is in the hashTable, return it If not, throw an IOException
	 */
	@Override
	public CourseDBElement get(int crn) throws IOException {
		
		for(int i = 0; i < getTableSize(); i++) {
			
			if(hashTable[i] == null)
				continue;
			
			LinkedList<CourseDBElement> copy = hashTable[i];
			
			for(int j = 0; j < copy.size(); j++) {
				if(copy.get(i).getCRN() == crn) {
					return copy.get(i);
				}
			}
		}
		throw new IOException();	
	}
	
	/**
	 * Returns the size of the ConcordanceDataStructure (number of indexes in the array)
	 */
	@Override
	public int getTableSize() {
		return size;
	}
	
	/**
	 * This method will display the CourseDBElement that were read. 
	 * @return An arrayList of Strings of elements.
	 */
	public ArrayList<String> showAll(){
		
		ArrayList<String> displayList = new ArrayList<String>();
		for(int i = 0; i < getTableSize(); i++)
		{
			if(hashTable[i] != null) 
			{
				LinkedList<CourseDBElement> copy = hashTable[i];
				for(CourseDBElement b : copy)
				{
					String cdeStr = "" + b;
					displayList.add(cdeStr);
				}
			}
		}
		Collections.sort(displayList);
		return displayList;
	}

}