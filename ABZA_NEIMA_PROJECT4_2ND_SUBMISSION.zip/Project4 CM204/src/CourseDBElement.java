/**
 * 
 * @author Neima Abza
 *
 */
public class CourseDBElement implements Comparable {
	/**
	 * Data fields
	 */
	private String courseID;
	private int CRN;
	private int credits;
	private String roomNumber;
	private String instructor;
	
	/**
	 * Default constructor 
	 */
	public CourseDBElement() {
		courseID = null;
		CRN = 0;
		credits = 0;
		roomNumber = null;
		instructor = null;
		
	}
	
	/**
	 * A constructor that takes parameters
	 * @param courseID
	 * @param crn
	 * @param credits
	 * @param roomNum
	 * @param instructor
	 */
	public CourseDBElement(String courseID, int crn, int credits, String roomNum, String instructor) {
		this.courseID = courseID;
		this.CRN = crn;
		this.credits = credits;
		this.roomNumber = roomNum;
		this.instructor = instructor;
	}
	/**
	 * Implements the comparable interface 
	 */
	@Override
	public int compareTo(CourseDBElement element) {
		
		String str = Integer.toString(element.getCRN());
		String str2 = Integer.toString(this.CRN);
		
		if(str2.compareTo(str) < 0)
			return -1;
		else if(str2.compareTo(str) > 0)
			return 1;
		else
			return 0;
	}
	
	/**
	 * Converts the search key to an integer 
	 */
	public int hashCode() {
		String Strcrn = Integer.toString(CRN);
		return Strcrn.hashCode();
	}

	public String StrCrn() {
		return Integer.toString(CRN);
	}
	
	public int getCRN() {
		return this.CRN;
	}

	public void setCRN(int parseInt) {
		this.CRN = parseInt; 
		
	}
	/**
	 * This represents the object as an a string.
	 */
	public String toString() {
		return "\nCourse:" + courseID + " CRN:" + CRN + " Credits:" + credits + " Instructor:" +
				instructor + " Room:" + roomNumber;
		
	}

}