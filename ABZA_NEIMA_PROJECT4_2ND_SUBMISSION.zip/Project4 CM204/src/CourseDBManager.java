
/**
 * @author Neima Abza
 */
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.Scanner;

public class CourseDBManager implements CourseDBManagerInterface{
	
	CourseDBStructure CDS = new CourseDBStructure(100);
	
    /**
     * This method uses the CourseDBStructure class add method to add the input that is read from a file 
     * or from the textfileds and added to the data structure.
     */
	@Override
	public void add(String id, int crn, int credits, String roomNum, String instructor) {
		CourseDBElement newElement = new CourseDBElement(id, crn, credits, roomNum, instructor);
        CDS.add(newElement);
	}
	
	/**
	 * This method calls the CourseDBStructure get() method to retrieve the course form the database using CRN
	 * 
	 */
	@Override
	public CourseDBElement get(int crn) {
		
		try {
			return CDS.get(crn);
		}
		catch (IOException e)
		{
			e.printStackTrace();
		}
		
		return null;
	}
	/**
	 * 
	 */
	@Override
	public void readFile(File input) throws FileNotFoundException {
		
		String id = "", strcrn = "",  strcredits = "", roomNum = "", instructor = "";
		int crn, credits;
		
		Scanner fileData = new Scanner(input);
		
		while(fileData.hasNext()) {
			
			if(fileData.hasNext()) {
				id = fileData.next();
			}
			if(fileData.hasNext()) {
				strcrn = fileData.next();
			}
			crn = Integer.parseInt(strcrn);
			
			if(fileData.hasNext()) {
				strcredits = fileData.next();
			}
			credits = Integer.parseInt(strcredits);
			
			if(fileData.hasNext()) {
				roomNum = fileData.next();
			}
			
			if(fileData.hasNext()) {
				instructor = fileData.nextLine();
			}
			
			add(id,crn,credits,roomNum,instructor);	
		}
		
		fileData.close();
	}
	/**
	 * 
	 */
	@Override
	public ArrayList<String> showAll() {
		
            ArrayList<String> list = new ArrayList<String>();
            for (int i = 0; i < CDS.hashTable.length; i++) { // loop through hashTable
                    LinkedList<CourseDBElement> tempList = CDS.hashTable[i];
                    if(tempList != null) {
                            for(int j = 0; j < tempList.size(); j++) { // loop through buckets
                                    CourseDBElement element = tempList.get(j);
                                    list.add(element.toString());
                            }
                    }
            }
            return list;
    }
}

