
/**
 * @author Neima
 *
 */
public interface Comparable {
	int compareTo(CourseDBElement element);

}
